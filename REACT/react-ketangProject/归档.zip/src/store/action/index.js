import course from './course'
import person from './person'
let action = {
    course,
    person
}
export default action
