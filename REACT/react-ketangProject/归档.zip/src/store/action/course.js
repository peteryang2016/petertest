import * as TYPES from '../action-types'

let course = {}
export default course
