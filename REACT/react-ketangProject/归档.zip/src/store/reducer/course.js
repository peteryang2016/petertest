import * as TYPES from '../action-types.js'
export default function course(state={},action) {
    state = JSON.parse(JSON.stringify(state))
    switch (action.type) {
    }
    return state
}
