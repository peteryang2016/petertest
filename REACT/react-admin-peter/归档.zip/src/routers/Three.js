import React from 'react'

export default class Three extends React.Component{
    constructor(props){
        super(props)
    }
    render(){
        return <div>Three</div>
    }
}
