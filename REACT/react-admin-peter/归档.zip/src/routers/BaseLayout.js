import React from 'react';
import { Layout, Menu, Breadcrumb, Icon } from 'antd';
import {Route,Redirect,Link,withRouter,Router,Switch} from 'react-router-dom'
import Home from './Home'
import First from './First'
import Three from './Three'
import Login from './Login'
import baselayout from './BaseLayout'
const { SubMenu } = Menu;
const { Header, Content, Sider } = Layout;



class BaseLayout extends React.Component{
    constructor(props){
        super(props)
        this.state={
            isLogin:JSON.parse(localStorage.getItem("isLogin")),
            defaultSelectedKeys:this.props.location.pathname
        }
    }
    render(){
        //this.setState({defaultSelectedKeys:this.props.location.pathname})
        return (
            <Layout>
                <Header className="header">
                    <div className="logo" />

                </Header>
                <Layout>
                    <Sider width={200} style={{ background: '#fff' }}>
                        <Menu
                            mode="inline"
                            defaultSelectedKeys={[this.state.defaultSelectedKeys]}
                            defaultOpenKeys={['sub1']}
                            style={{ height: '100%', borderRight: 0 }}
                        >
                            <Menu.Item key="/">
                                <Link to="/baselayout/home">
                                    <Icon type="pie-chart" />
                                    <span>首页</span>
                                </Link>
                            </Menu.Item>

                            <SubMenu
                                key="sub1"
                                title={
                                    <span>
                <Icon type="user" />
                用户管理
              </span>
                                }
                            >
                                <Menu.Item key="/user/first"><Link to="/user/first">个人设置</Link></Menu.Item>
                                <Menu.Item key="/user/three"><Link to="/user/three">账户管理</Link></Menu.Item>
                            </SubMenu>
                        </Menu>
                    </Sider>
                    <Layout style={{ padding: '0 24px 24px' }}>
                        <Breadcrumb style={{ margin: '16px 0' }}>
                            <Breadcrumb.Item>Home</Breadcrumb.Item>
                            <Breadcrumb.Item>List</Breadcrumb.Item>
                            <Breadcrumb.Item>App</Breadcrumb.Item>
                        </Breadcrumb>
                        <Content
                            style={{
                                background: '#fff',
                                padding: 24,
                                margin: 0,
                                minHeight: 280,
                            }}
                        >
                                <Switch>
                                    <Route path="/" exact component={Home}/>
                                    <Route path="/user/home" component={Home}/>
                                    <Route path="/user/first" component={First}/>
                                    <Route path="/user/three" component={Three}/>
                                </Switch>
                        </Content>
                    </Layout>
                </Layout>
            </Layout>
        );
    }
}


export default withRouter(BaseLayout);
