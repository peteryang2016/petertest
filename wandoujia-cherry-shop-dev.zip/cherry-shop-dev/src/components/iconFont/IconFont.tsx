import React, {FC} from 'react'
import {Icon} from 'antd'

// 这是阿里的iconFont图标图
const IconFont = Icon.createFromIconfontCN({
  scriptUrl: '//at.alicdn.com/t/font_1253945_veeh4b19c3e.js',
})
export default IconFont
