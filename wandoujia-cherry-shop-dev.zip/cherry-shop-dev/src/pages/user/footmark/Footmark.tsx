import React ,{ FC } from 'react' 
interface FontmarkProp {}
const Footmark:FC<FontmarkProp> = ()=>{ return <div> Footmark </div> }
export default Footmark
