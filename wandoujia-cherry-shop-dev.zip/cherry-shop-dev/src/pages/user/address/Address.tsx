import React ,{ FC } from 'react' 
interface AddressProp {}
const Address:FC<AddressProp> = ()=>{ return <div> Address </div> }
export default Address