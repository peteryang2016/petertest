import React ,{ FC } from 'react' 
interface CollectProp {}
const Collect:FC<CollectProp> = ()=>{ return <div> Collect </div> }
export default Collect