import React, {FC} from 'react'
interface FeedBackProp {}
const Feedback: FC<FeedBackProp> = () => {
  return <div> FeedBack </div>
}
export default Feedback
