import React ,{ FC } from 'react' 
interface HistoryProp {}
const History:FC<HistoryProp> = ()=>{ return <div> History </div> }
export default History