import React ,{ FC } from 'react' 
interface LoginProp {}
const Login:FC<LoginProp> = ()=>{ return <div> Login </div> }
export default Login