import React ,{ FC } from 'react' 
interface WechatProp {}
const Wechat:FC<WechatProp> = ()=>{ return <div> Wechat </div> }
export default Wechat