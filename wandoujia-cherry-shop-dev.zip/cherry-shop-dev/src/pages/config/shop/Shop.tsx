import React ,{ FC } from 'react' 
interface ShopProp {}
const Shop:FC<ShopProp> = ()=>{ return <div> Shop </div> }
export default Shop