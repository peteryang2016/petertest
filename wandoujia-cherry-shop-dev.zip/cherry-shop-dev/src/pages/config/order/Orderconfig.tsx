import React, {FC} from 'react'
interface OrderconfigProp {}
const Orderconfig: FC<OrderconfigProp> = () => {
  return <div> Order </div>
}
export default Orderconfig
