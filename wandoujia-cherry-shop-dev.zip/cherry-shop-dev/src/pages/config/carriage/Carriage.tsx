import React, {FC} from 'react'
interface carriageProp {}
const Carriage: FC<carriageProp> = () => {
  return <div>Carriage</div>
}
export default Carriage
