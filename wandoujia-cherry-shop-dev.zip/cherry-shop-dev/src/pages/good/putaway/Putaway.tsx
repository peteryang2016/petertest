import React ,{ FC } from 'react' 
interface PutawayProp {}
const Putaway:FC<PutawayProp> = ()=>{ return <div> Putaway </div> }
export default Putaway