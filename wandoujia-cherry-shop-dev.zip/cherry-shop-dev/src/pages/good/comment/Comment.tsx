import React ,{ FC } from 'react' 
interface CommentProp {}
const Comment:FC<CommentProp> = ()=>{ return <div> Comment </div> }
export default Comment