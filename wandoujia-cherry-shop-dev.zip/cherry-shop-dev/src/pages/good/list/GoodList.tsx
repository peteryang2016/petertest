import React ,{ FC } from 'react' 
interface GoodListProp {}
const GoodList:FC<GoodListProp> = ()=>{ return <div> GoodList </div> }
export default GoodList