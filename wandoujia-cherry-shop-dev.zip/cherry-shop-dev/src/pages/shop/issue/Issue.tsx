import React ,{ FC } from 'react' 
interface IssueProp {}
const Issue:FC<IssueProp> = ()=>{ return <div> Issue </div> }
export default Issue