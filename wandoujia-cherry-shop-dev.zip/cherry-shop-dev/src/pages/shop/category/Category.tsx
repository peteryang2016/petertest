import React ,{ FC } from 'react' 
interface CategoryProp {}
const Category:FC<CategoryProp> = ()=>{ return <div> Category </div> }
export default Category