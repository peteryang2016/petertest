import React ,{ FC } from 'react' 
interface KeyboardProp {}
const Keyboard:FC<KeyboardProp> = ()=>{ return <div> Keyboard </div> }
export default Keyboard