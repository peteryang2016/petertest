import React ,{ FC } from 'react' 
interface AdminProp {}
const Admin:FC<AdminProp> = ()=>{ return <div> Admin </div> }
export default Admin