import React ,{ FC } from 'react' 
interface LogProp {}
const Log:FC<LogProp> = ()=>{ return <div> Log </div> }
export default Log