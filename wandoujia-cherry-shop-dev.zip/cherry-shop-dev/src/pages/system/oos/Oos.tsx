import React ,{ FC } from 'react' 
interface OosProp {}
const Oos:FC<OosProp> = ()=>{ return <div> Oos </div> }
export default Oos