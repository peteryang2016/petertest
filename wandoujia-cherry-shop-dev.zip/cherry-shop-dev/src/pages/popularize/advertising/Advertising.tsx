import React ,{ FC } from 'react' 
interface AdvertisingProp {}
const Advertising:FC<AdvertisingProp> = ()=>{ return <div> Advertising </div> }
export default Advertising