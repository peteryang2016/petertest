import React ,{ FC } from 'react' 
interface GrouproleProp {}
const Grouprole:FC<GrouproleProp> = ()=>{ return <div> Grouprole </div> }
export default Grouprole