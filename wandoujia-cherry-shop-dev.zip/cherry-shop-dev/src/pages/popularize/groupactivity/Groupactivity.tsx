import React ,{ FC } from 'react' 
interface GroupactivityProp {}
const Groupactivity:FC<GroupactivityProp> = ()=>{ return <div> Groupactivity </div> }
export default Groupactivity