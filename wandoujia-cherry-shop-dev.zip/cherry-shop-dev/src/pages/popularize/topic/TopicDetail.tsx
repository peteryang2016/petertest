import React ,{ FC } from 'react' 
interface TopicDetailProp {}
const TopicDetail:FC<TopicDetailProp> = ()=>{ return <div> TopicDetail </div> }
export default TopicDetail