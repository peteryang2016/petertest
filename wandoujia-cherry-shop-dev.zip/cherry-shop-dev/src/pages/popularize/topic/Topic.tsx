import React ,{ FC } from 'react' 
interface TopicProp {}
const Topic:FC<TopicProp> = ()=>{ return <div> Topic </div> }
export default Topic