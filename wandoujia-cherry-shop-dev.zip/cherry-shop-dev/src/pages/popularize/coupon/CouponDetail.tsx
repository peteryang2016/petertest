import React ,{ FC } from 'react' 
interface CouponDetailProp {}
const CouponDetail:FC<CouponDetailProp> = ()=>{ return <div> CouponDetail </div> }
export default CouponDetail
