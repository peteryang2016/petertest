import React ,{ FC } from 'react' 
interface CouponProp {}
const Coupon:FC<CouponProp> = ()=>{ return <div> Coupon </div> }
export default Coupon