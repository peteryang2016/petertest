husky: 用来拦截 git 命令 执行一些 npm 的测试等以及错误提示
